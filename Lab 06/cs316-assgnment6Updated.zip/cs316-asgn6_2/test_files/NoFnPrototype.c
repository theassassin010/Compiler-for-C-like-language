void main();

main()
{
	int a;
	a = 3;
	fn(a, 4);
	return;
}

fn(int a, int b)	
{
	a = a + b;
	return;
}
